# 287_Assignment3
This is a php/html/css/js website that was done as a 6 person group project for school. We ran it through MAMP.

I contributed mainly to the order list backpage.

To access the backpages through the main pages, you can login as the admin:
username: admin
password: admin

Website creators:
Melisa Panaccione
Mouhamed Diane
Haytham Hnine
Anjali Bhardwaj
Michael Roubeiz
Warda Ahmed Salem
