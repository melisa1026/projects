<!DOCTYPE html>
<html>
<head></head>
<body>
<script>
   var ans = confirm("You are no longer logged in. Redirecting...");
   if (ans == true){
    location.href = 'P5.php';
   }
</script>
</body>
</html>