<?php 
    unset($_SESSION["email"]);
    header("Location: redirectToLogin.php");

?>