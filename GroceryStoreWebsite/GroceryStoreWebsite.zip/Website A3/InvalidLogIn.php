<!DOCTYPE html>
<html>
<head></head>
<body>
<script>
   var ans = confirm("Email or Password is wrong, or this account may not exist...");
   if (ans == true){
    location.href = 'LogIn.php';
   }
</script>
</body>
</html>